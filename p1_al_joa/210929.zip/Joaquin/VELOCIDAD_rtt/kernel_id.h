/*
 *  kernel_id.h
 *  Fri Oct 18 16:17:23 2013
 *  SG Version 2.00
 *  sg ./mine.oil -os=ECC2 -IC:/MATLAB/SupportPackages/R2014aPrerelease_Test1/nxtOSEK/toppers_osek/sg/impl_oil -template=C:/MATLAB/SupportPackages/R2014aPrerelease_Test1/nxtOSEK/toppers_osek/sg/lego_nxt.sgt
 */
#ifndef KERNEL_ID_H
#define KERNEL_ID_H

 /****** Object OS ******/


 /****** Object TASK ******/

 /****** Object COUNTER ******/

 /****** Object ALARM ******/

 /****** Object RESOURCE ******/

 /****** Object EVENT ******/

 /****** Object ISR ******/

 /****** Object APPMODE ******/

#define RTT_LEGO	(AppModeType)( 1U << 0 )

#endif	/* ! KERNEL_ID_H */

